# 华为PC营销软文智能体 · 前端

> 赛题：AI+华为PC营销软文智能体（产业进阶赛道）  
> 技术：纯静态 HTML / CSS / JS，无构建步骤、无框架、无 API Key  
> 视觉：深空工作台 + 华为红 · 合规签章为主角

## 如何打开

1. 将整个 `frontend` 文件夹拷到本机（本仓库路径：`华为赛题/frontend`）。
2. 用浏览器直接打开 `index.html`（双击或拖入 Chrome / Edge）。
3. 也可本地起静态服务（可选）：
   ```bash
   # Python
   python -m http.server 8080
   # 然后访问 http://localhost:8080
   ```
4. 需联网加载 Google Fonts（Sora / Noto Sans SC / Noto Serif SC）。离线时会回退系统字体，布局仍可用。

## 页面地图

| 路由 Hash | 页面 | 职责 |
|---|---|---|
| `#connect` | 连接页 | 账号掩码、指定知识库、API 探测；确认后解锁任务 |
| `#task` | 任务页 | TaskSpec 表单；缺项黄条追问；预览句 |
| `#strategy` | 策略页 | ContentPlan（切角/卖点/结构/语气/配图/CTA）+ 平台差异说明 |
| `#draft` | 成稿页 | 左 EvidenceMap · 中稿纸+四段 Tab · 右合规签章；七层流水线动画 |
| `#revise` | 修订页 | 删段/换渠道/换卖点/改 CTA → 重跑 5→6；复制 / MD / TXT 导出 |

顶栏步骤条：未完成前置步骤的页不可跳入；核验 `FAIL` 时不解锁「修订」。

## 演示默认值

- 产品：MateBook X Pro 2024  
- 人群：大学新生  
- 场景：开学季  
- 渠道：小红书  
- 目标：种草+到店  

换「公众号 / 朋友圈 / 海报」会得到不同 ContentPlan 与文风。价格字段在 Mock 中无依据，核验签章为 **待确认（WARN）**，正文不写报价。

## 目录结构

```
frontend/
  index.html          # 结构与 5 页 DOM
  css/styles.css      # 视觉规范（CSS 变量）
  js/mock-data.js     # Mock 账号/知识库/策略规则/成稿/核验
  js/app.js           # Hash 路由、表单、流水线、导出
  docs/               # 方案包与 frontend-design skill
  README.md           # 本说明
```

## 技术说明

- **无后端**：生成与核验均为前端规则 Mock，便于评委离线演示 UI。
- **无密钥**：Client ID 仅掩码；不出现完整 API Key。
- **无外图**：图片为占位块，来源字符串形如 `ima://...`，型号与产品绑定校验。
- **无障碍**：语义化标签、可见 `:focus-visible`、签章 `aria-live`。
- **动效**：尊重 `prefers-reduced-motion`（流水线加速/取消动画）。
- **导出**：`Blob` + `<a download>`；复制依赖 `navigator.clipboard`（部分 `file://` 环境可能受限，可改用导出文件）。

## 与后端七层的对应

```
1 意图理解 → 任务页 TaskSpec
2 平台策略 → 策略页 ContentPlan
3–4 ima 检索/事实 → 成稿页左栏 EvidenceMap
5 图文编排 → 成稿页中栏 DraftArticle
6 核验合规 → 成稿页右栏 VerificationReport（签章）
7 反馈修改 → 修订页重跑 5→6 + 导出
```

## 文档

见 `docs/`：

- `完整前端与产品方案.md`
- `自研Agent架构方案-v1.md`
- `frontend-design.SKILL.md` + `LICENSE.txt`
- `如何安装 frontend-design skill.md`

## 限制（诚实清单）

1. 当前为 **UI + Mock**，未接真实 ima OpenAPI。  
2. 配图为 CSS 占位，非真实二进制资源。  
3. 合规/事实规则为演示集，生产需接后端核验服务。  
4. `file://` 下剪贴板 API 可能不可用，请用「导出」按钮。  
5. 桌面优先（约 1280px）；窄屏会单列堆叠成稿三栏。
